﻿using System;

public class JuniorTrainer : Trainer
{
    public JuniorTrainer(string firstName, string lastName, byte age)
        : base(firstName, lastName, age)
    {
    }
}